//Doctor Form Validation
       function formValidation(){
            $(document).ready(function () {

                function NICValidation(value, element) {
                    return /^[0-9]{9}[VXvx]+$/.test(value);
                }
                function NameValidation(value, element) {
                    return /^[a-zA-Z.\s]+$/.test(value);
                }
                function PhoneValidation(value, element) {
                    return /[0-9]{10}/.test(value);
                }

                $.validator.addMethod("nic", NICValidation, "Please insert valid NIC format");
                $.validator.addMethod("character_v", NameValidation, "Please insert only alphabetic characters with . or spaces");
                $.validator.addMethod("phone_number", PhoneValidation, "Please insert only numeric characters");

                $("#doctor_registration_form").validate({
                    rules: {
                        gov_reg_num: {
                            required: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorRegNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_title: {
                            required: true
                        },
                        doctor_initials: {
                            character_v: true
                        },
                        doctor_fname: {
                            required: true,
                            character_v: true
                        },
                        doctor_lname: {
                            required: true,
                            character_v: true
                        },
                        doctor_bday: {
                            required: true
                        },
                        doctor_email: {
                            required: true,
                            email: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorEmail",
                                type: "post", async: true
                            }
                        },
                        doctor_nic: {
                            required: true,
                            nic: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorNICNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_gender: {
                            required: true
                        },
                        doctor_address: {
                            required: true
                        },
                        doctor_city: {
                            required: true
                        },
                        doctor_mobile: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_tele: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_image: {
                            accept: "image/*"
                        }
                    },
                    messages: {
                        gov_reg_num: {
                            remote: "Registration number already exist",
                            required: "Registration number is required"
                        },
                        doctor_title: {
                            required: "Title is required"
                        },
                        doctor_initials: {
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_fname: {
                            required: "First name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_lname: {
                            required: "Last name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_bday: {
                            required: "Birthday is required"
                        },
                        doctor_email: {
                            remote: "Email already exist",
                            required: "Email is required"
                        },
                        doctor_nic: {
                            required: "NIC is required",
                            nic: "Enter a valid NIC",
                            remote: "NIC already exist"
                        },
                        doctor_gender: {
                            required: "Gender is required"
                        },
                        doctor_address: {
                            required: "Address is required"
                        },
                        doctor_city: {
                            required: "City is required"
                        },
                        doctor_mobile: {
                            required: "Mobile is required",
                            phone_number: "Insert only numeric characters"
                        },
                        doctor_tele: {
                            required: "Telephone is required",
                            phone_number: "Insert only numeric characters"
                        }
                    }
                });
                
                //Dictor updae form validation
                 $("#doctor_update_form").validate({
                    rules: {
                        gov_reg_num: {
                            required: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorRegNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_title: {
                            required: true
                        },
                        doctor_initials: {
                            character_v: true
                        },
                        doctor_fname: {
                            required: true,
                            character_v: true
                        },
                        doctor_lname: {
                            required: true,
                            character_v: true
                        },
                        doctor_bday: {
                            required: true
                        },
                        doctor_email: {
                            required: true,
                            email: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorEmail",
                                type: "post", async: true
                            }
                        },
                        doctor_nic: {
                            required: true,
                            nic: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorNICNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_gender: {
                            required: true
                        },
                        doctor_address: {
                            required: true
                        },
                        doctor_city: {
                            required: true
                        },
                        doctor_mobile: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_tele: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_image: {
                            accept: "image/*"
                        }
                    },
                    messages: {
                        gov_reg_num: {
                            remote: "Registration number already exist",
                            required: "Registration number is required"
                        },
                        doctor_title: {
                            required: "Title is required"
                        },
                        doctor_initials: {
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_fname: {
                            required: "First name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_lname: {
                            required: "Last name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_bday: {
                            required: "Birthday is required"
                        },
                        doctor_email: {
                            remote: "Email already exist",
                            required: "Email is required"
                        },
                        doctor_nic: {
                            required: "NIC is required",
                            nic: "Enter a valid NIC",
                            remote: "NIC already exist"
                        },
                        doctor_gender: {
                            required: "Gender is required"
                        },
                        doctor_address: {
                            required: "Address is required"
                        },
                        doctor_city: {
                            required: "City is required"
                        },
                        doctor_mobile: {
                            required: "Mobile is required",
                            phone_number: "Insert only numeric characters"
                        },
                        doctor_tele: {
                            required: "Telephone is required",
                            phone_number: "Insert only numeric characters"
                        }
                    }
                });
                
                //nurse add form validation
                
                 $("#").validate({
                    rules: {
                        gov_reg_num: {
                            required: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorRegNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_title: {
                            required: true
                        },
                        doctor_initials: {
                            character_v: true
                        },
                        doctor_fname: {
                            required: true,
                            character_v: true
                        },
                        doctor_lname: {
                            required: true,
                            character_v: true
                        },
                        doctor_bday: {
                            required: true
                        },
                        doctor_email: {
                            required: true,
                            email: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorEmail",
                                type: "post", async: true
                            }
                        },
                        doctor_nic: {
                            required: true,
                            nic: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorNICNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_gender: {
                            required: true
                        },
                        doctor_address: {
                            required: true
                        },
                        doctor_city: {
                            required: true
                        },
                        doctor_mobile: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_tele: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_image: {
                            accept: "image/*"
                        }
                    },
                    messages: {
                        gov_reg_num: {
                            remote: "Registration number already exist",
                            required: "Registration number is required"
                        },
                        doctor_title: {
                            required: "Title is required"
                        },
                        doctor_initials: {
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_fname: {
                            required: "First name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_lname: {
                            required: "Last name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_bday: {
                            required: "Birthday is required"
                        },
                        doctor_email: {
                            remote: "Email already exist",
                            required: "Email is required"
                        },
                        doctor_nic: {
                            required: "NIC is required",
                            nic: "Enter a valid NIC",
                            remote: "NIC already exist"
                        },
                        doctor_gender: {
                            required: "Gender is required"
                        },
                        doctor_address: {
                            required: "Address is required"
                        },
                        doctor_city: {
                            required: "City is required"
                        },
                        doctor_mobile: {
                            required: "Mobile is required",
                            phone_number: "Insert only numeric characters"
                        },
                        doctor_tele: {
                            required: "Telephone is required",
                            phone_number: "Insert only numeric characters"
                        }
                    }
                });
                
                //nurse update form validation 
                 $("#").validate({
                    rules: {
                        gov_reg_num: {
                            required: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorRegNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_title: {
                            required: true
                        },
                        doctor_initials: {
                            character_v: true
                        },
                        doctor_fname: {
                            required: true,
                            character_v: true
                        },
                        doctor_lname: {
                            required: true,
                            character_v: true
                        },
                        doctor_bday: {
                            required: true
                        },
                        doctor_email: {
                            required: true,
                            email: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorEmail",
                                type: "post", async: true
                            }
                        },
                        doctor_nic: {
                            required: true,
                            nic: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorNICNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_gender: {
                            required: true
                        },
                        doctor_address: {
                            required: true
                        },
                        doctor_city: {
                            required: true
                        },
                        doctor_mobile: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_tele: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_image: {
                            accept: "image/*"
                        }
                    },
                    messages: {
                        gov_reg_num: {
                            remote: "Registration number already exist",
                            required: "Registration number is required"
                        },
                        doctor_title: {
                            required: "Title is required"
                        },
                        doctor_initials: {
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_fname: {
                            required: "First name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_lname: {
                            required: "Last name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_bday: {
                            required: "Birthday is required"
                        },
                        doctor_email: {
                            remote: "Email already exist",
                            required: "Email is required"
                        },
                        doctor_nic: {
                            required: "NIC is required",
                            nic: "Enter a valid NIC",
                            remote: "NIC already exist"
                        },
                        doctor_gender: {
                            required: "Gender is required"
                        },
                        doctor_address: {
                            required: "Address is required"
                        },
                        doctor_city: {
                            required: "City is required"
                        },
                        doctor_mobile: {
                            required: "Mobile is required",
                            phone_number: "Insert only numeric characters"
                        },
                        doctor_tele: {
                            required: "Telephone is required",
                            phone_number: "Insert only numeric characters"
                        }
                    }
                });
                
                //pet owner add form validation 
                 $("#").validate({
                    rules: {
                        gov_reg_num: {
                            required: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorRegNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_title: {
                            required: true
                        },
                        doctor_initials: {
                            character_v: true
                        },
                        doctor_fname: {
                            required: true,
                            character_v: true
                        },
                        doctor_lname: {
                            required: true,
                            character_v: true
                        },
                        doctor_bday: {
                            required: true
                        },
                        doctor_email: {
                            required: true,
                            email: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorEmail",
                                type: "post", async: true
                            }
                        },
                        doctor_nic: {
                            required: true,
                            nic: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorNICNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_gender: {
                            required: true
                        },
                        doctor_address: {
                            required: true
                        },
                        doctor_city: {
                            required: true
                        },
                        doctor_mobile: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_tele: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_image: {
                            accept: "image/*"
                        }
                    },
                    messages: {
                        gov_reg_num: {
                            remote: "Registration number already exist",
                            required: "Registration number is required"
                        },
                        doctor_title: {
                            required: "Title is required"
                        },
                        doctor_initials: {
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_fname: {
                            required: "First name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_lname: {
                            required: "Last name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_bday: {
                            required: "Birthday is required"
                        },
                        doctor_email: {
                            remote: "Email already exist",
                            required: "Email is required"
                        },
                        doctor_nic: {
                            required: "NIC is required",
                            nic: "Enter a valid NIC",
                            remote: "NIC already exist"
                        },
                        doctor_gender: {
                            required: "Gender is required"
                        },
                        doctor_address: {
                            required: "Address is required"
                        },
                        doctor_city: {
                            required: "City is required"
                        },
                        doctor_mobile: {
                            required: "Mobile is required",
                            phone_number: "Insert only numeric characters"
                        },
                        doctor_tele: {
                            required: "Telephone is required",
                            phone_number: "Insert only numeric characters"
                        }
                    }
                });
                
                //pet owner update form validation
                 $("#").validate({
                    rules: {
                        gov_reg_num: {
                            required: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorRegNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_title: {
                            required: true
                        },
                        doctor_initials: {
                            character_v: true
                        },
                        doctor_fname: {
                            required: true,
                            character_v: true
                        },
                        doctor_lname: {
                            required: true,
                            character_v: true
                        },
                        doctor_bday: {
                            required: true
                        },
                        doctor_email: {
                            required: true,
                            email: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorEmail",
                                type: "post", async: true
                            }
                        },
                        doctor_nic: {
                            required: true,
                            nic: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorNICNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_gender: {
                            required: true
                        },
                        doctor_address: {
                            required: true
                        },
                        doctor_city: {
                            required: true
                        },
                        doctor_mobile: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_tele: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_image: {
                            accept: "image/*"
                        }
                    },
                    messages: {
                        gov_reg_num: {
                            remote: "Registration number already exist",
                            required: "Registration number is required"
                        },
                        doctor_title: {
                            required: "Title is required"
                        },
                        doctor_initials: {
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_fname: {
                            required: "First name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_lname: {
                            required: "Last name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_bday: {
                            required: "Birthday is required"
                        },
                        doctor_email: {
                            remote: "Email already exist",
                            required: "Email is required"
                        },
                        doctor_nic: {
                            required: "NIC is required",
                            nic: "Enter a valid NIC",
                            remote: "NIC already exist"
                        },
                        doctor_gender: {
                            required: "Gender is required"
                        },
                        doctor_address: {
                            required: "Address is required"
                        },
                        doctor_city: {
                            required: "City is required"
                        },
                        doctor_mobile: {
                            required: "Mobile is required",
                            phone_number: "Insert only numeric characters"
                        },
                        doctor_tele: {
                            required: "Telephone is required",
                            phone_number: "Insert only numeric characters"
                        }
                    }
                });
                
                //pet add form validation
                 $("#").validate({
                    rules: {
                        gov_reg_num: {
                            required: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorRegNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_title: {
                            required: true
                        },
                        doctor_initials: {
                            character_v: true
                        },
                        doctor_fname: {
                            required: true,
                            character_v: true
                        },
                        doctor_lname: {
                            required: true,
                            character_v: true
                        },
                        doctor_bday: {
                            required: true
                        },
                        doctor_email: {
                            required: true,
                            email: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorEmail",
                                type: "post", async: true
                            }
                        },
                        doctor_nic: {
                            required: true,
                            nic: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorNICNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_gender: {
                            required: true
                        },
                        doctor_address: {
                            required: true
                        },
                        doctor_city: {
                            required: true
                        },
                        doctor_mobile: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_tele: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_image: {
                            accept: "image/*"
                        }
                    },
                    messages: {
                        gov_reg_num: {
                            remote: "Registration number already exist",
                            required: "Registration number is required"
                        },
                        doctor_title: {
                            required: "Title is required"
                        },
                        doctor_initials: {
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_fname: {
                            required: "First name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_lname: {
                            required: "Last name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_bday: {
                            required: "Birthday is required"
                        },
                        doctor_email: {
                            remote: "Email already exist",
                            required: "Email is required"
                        },
                        doctor_nic: {
                            required: "NIC is required",
                            nic: "Enter a valid NIC",
                            remote: "NIC already exist"
                        },
                        doctor_gender: {
                            required: "Gender is required"
                        },
                        doctor_address: {
                            required: "Address is required"
                        },
                        doctor_city: {
                            required: "City is required"
                        },
                        doctor_mobile: {
                            required: "Mobile is required",
                            phone_number: "Insert only numeric characters"
                        },
                        doctor_tele: {
                            required: "Telephone is required",
                            phone_number: "Insert only numeric characters"
                        }
                    }
                });
                
                //pet update form validation
                 $("#").validate({
                    rules: {
                        gov_reg_num: {
                            required: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorRegNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_title: {
                            required: true
                        },
                        doctor_initials: {
                            character_v: true
                        },
                        doctor_fname: {
                            required: true,
                            character_v: true
                        },
                        doctor_lname: {
                            required: true,
                            character_v: true
                        },
                        doctor_bday: {
                            required: true
                        },
                        doctor_email: {
                            required: true,
                            email: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorEmail",
                                type: "post", async: true
                            }
                        },
                        doctor_nic: {
                            required: true,
                            nic: true,
                            remote: {
                                url: "http://localhost/healthcare_management2/index.php/doctor/checkDoctorNICNumber",
                                type: "post", async: true
                            }
                        },
                        doctor_gender: {
                            required: true
                        },
                        doctor_address: {
                            required: true
                        },
                        doctor_city: {
                            required: true
                        },
                        doctor_mobile: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_tele: {
                            required: true,
                            minlength: "10",
                            phone_number: true
                        },
                        doctor_image: {
                            accept: "image/*"
                        }
                    },
                    messages: {
                        gov_reg_num: {
                            remote: "Registration number already exist",
                            required: "Registration number is required"
                        },
                        doctor_title: {
                            required: "Title is required"
                        },
                        doctor_initials: {
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_fname: {
                            required: "First name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_lname: {
                            required: "Last name is required",
                            character_v: "Insert only alphabetic characters"
                        },
                        doctor_bday: {
                            required: "Birthday is required"
                        },
                        doctor_email: {
                            remote: "Email already exist",
                            required: "Email is required"
                        },
                        doctor_nic: {
                            required: "NIC is required",
                            nic: "Enter a valid NIC",
                            remote: "NIC already exist"
                        },
                        doctor_gender: {
                            required: "Gender is required"
                        },
                        doctor_address: {
                            required: "Address is required"
                        },
                        doctor_city: {
                            required: "City is required"
                        },
                        doctor_mobile: {
                            required: "Mobile is required",
                            phone_number: "Insert only numeric characters"
                        },
                        doctor_tele: {
                            required: "Telephone is required",
                            phone_number: "Insert only numeric characters"
                        }
                    }
                });
                
            });
        
       }